package com.example.android.mybhamashah;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class updations extends AppCompatActivity
{
    EditText name,date,number,parivar,city,village,category,updation,changes;
    Button submit;
    DatabaseReference databaseentry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_updations );
        name = (EditText) findViewById ( R.id.name );
        date = (EditText) findViewById ( R.id.date );
        number = (EditText) findViewById ( R.id.number );
        parivar = (EditText) findViewById ( R.id.parivar );
        city = (EditText) findViewById ( R.id.city );
        village = (EditText) findViewById ( R.id.village );
        category = (EditText) findViewById ( R.id.category );
        updation = (EditText) findViewById ( R.id.updation );
        changes = (EditText) findViewById ( R.id.changes );
        databaseentry = FirebaseDatabase.getInstance ().getReference ("entries1");
        submit=(Button)findViewById ( R.id.submit );
        submit.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick(View view) {

                values();

            }
        } );
    }
    private void values() {
        String namee=name.getText ().toString ().trim ();
        String datee=date.getText ().toString ().trim ();
        String numberr=number.getText ().toString ().trim ();
        String parivarr=parivar.getText ().toString ().trim ();
        String cityy=city.getText ().toString ().trim ();
        String villagee=village.getText ().toString ().trim ();
        String categoryy=category.getText ().toString ().trim ();
        String updations=updation.getText ().toString ().trim ();
        String changess=changes.getText ().toString ().trim ();
        String id=databaseentry.push ().getKey ();
        entry1 Entry =new entry1 (id,namee,  datee,  numberr,  parivarr,  cityy,  villagee,  categoryy,updations,changess );
        databaseentry.setValue ( Entry );
        Intent i=new Intent ( updations.this,index.class );
        startActivity( i );
        Toast.makeText ( updations.this,"Updations Will Be Made Soon" ,Toast.LENGTH_SHORT).show ();

    }

    public void index(View view)
    {
        Intent i=new Intent ( updations.this,index.class );
        startActivity( i );
        Toast.makeText ( updations.this,"Updations Will Be Made Soon" ,Toast.LENGTH_SHORT).show ();
    }
}
