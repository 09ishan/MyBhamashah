package com.example.android.mybhamashah;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class complaints extends AppCompatActivity {
    EditText name ,date,number,parivar,city,village,category,description;
    Button buttonc;

    DatabaseReference databaseentry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_complaints );

        name = (EditText) findViewById ( R.id.name );
        date = (EditText) findViewById ( R.id.date );
        number = (EditText) findViewById ( R.id.number );
        parivar = (EditText) findViewById ( R.id.parivar );
        city = (EditText) findViewById ( R.id.city );
        village = (EditText) findViewById ( R.id.village );
        category = (EditText) findViewById ( R.id.category );
        description = (EditText) findViewById ( R.id.description );
        databaseentry = FirebaseDatabase.getInstance ().getReference ("entries");
        buttonc=(Button)findViewById ( R.id.buttonc );
        buttonc.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick(View view) {

                values();

            }
        } );
    }

    private void values() {
        String namee=name.getText ().toString ().trim ();
        String datee=date.getText ().toString ().trim ();
        String numberr=number.getText ().toString ().trim ();
        String parivarr=parivar.getText ().toString ().trim ();
        String cityy=city.getText ().toString ().trim ();
        String villagee=village.getText ().toString ().trim ();
        String categoryy=category.getText ().toString ().trim ();
        String discriptionn=description.getText ().toString ().trim ();
        String id=databaseentry.push ().getKey ();
        entry Entry =new entry (id,namee,  datee,  numberr,  parivarr,  cityy,  villagee,  categoryy,discriptionn );
        databaseentry.setValue ( Entry );
        Intent i=new Intent ( complaints.this,index.class );
        startActivity ( i );
        Toast.makeText (complaints.this,"Complaint Filed", Toast.LENGTH_SHORT).show ();

    }


    public void index(View view) {
        Intent i=new Intent ( complaints.this,index.class );
        startActivity ( i );
        Toast.makeText (complaints.this,"Complaint Filed", Toast.LENGTH_SHORT).show ();
    }
}
