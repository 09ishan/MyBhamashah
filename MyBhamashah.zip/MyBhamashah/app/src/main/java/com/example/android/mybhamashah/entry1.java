package com.example.android.mybhamashah;

import android.widget.EditText;

/**
 * Created by Ishan on 20/03/18.
 */

public class entry1 {
    String id,namee,  date,  number,  parivar,  city,  village,  category,updations,changes;
    public entry1(){


    }

    public entry1(String id, String namee, String date, String number, String parivar, String city, String village, String category, String updations, String changes) {
        this.id = id;
        this.namee = namee;
        this.date = date;
        this.number = number;
        this.parivar = parivar;
        this.city = city;
        this.village = village;
        this.category = category;
        this.updations = updations;
        this.changes = changes;
    }

    public String getId() {
        return id;
    }

    public String getNamee() {
        return namee;
    }

    public String getDate() {
        return date;
    }

    public String getNumber() {
        return number;
    }

    public String getParivar() {
        return parivar;
    }

    public String getCity() {
        return city;
    }

    public String getVillage() {
        return village;
    }

    public String getCategory() {
        return category;
    }

    public String getUpdations() {
        return updations;
    }

    public String getChanges() {
        return changes;
    }
}
