package com.example.android.mybhamashah;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_about );
    }

    public void index(View view) {
        Intent i=new Intent ( about.this,index.class );
        startActivity ( i );
    }
}
