package com.example.android.mybhamashah;

import android.widget.EditText;

/**
 * Created by Ishan on 20/03/18.
 */

public class entry {

    String id, name ,date,number,parivar,city,village,category,description;

    public entry(String id, String name, String date, String number, String parivar, String city, String village, String category, String description) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.number = number;
        this.parivar = parivar;
        this.city = city;
        this.village = village;
        this.category = category;
        this.description = description;
    }

    public entry(){


    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getNumber() {
        return number;
    }

    public String getParivar() {
        return parivar;
    }

    public String getCity() {
        return city;
    }

    public String getVillage() {
        return village;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }
}
